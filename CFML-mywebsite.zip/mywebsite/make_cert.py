r"""
make_cert.py — create a self-signed certificate for rubaya.com

Only needed if you want the camera to work at rubaya.com or your LAN address
without passing a Chrome flag every time. http://127.0.0.1 needs none of this —
browsers already treat it as secure.

    pip install cryptography
    python make_cert.py

Writes certs\cert.pem and certs\key.pem, valid for two years, covering
rubaya.com, 127.0.0.1, localhost, and this machine's LAN address (detected
automatically). If the address changed since last time, or the automatic
detection is wrong, add it explicitly:

    python make_cert.py 192.168.0.111

Chrome will still warn that it does not know who signed it. To stop the
warning, trust the certificate once, from an Administrator Command Prompt:

    certutil -addstore -f "ROOT" certs\cert.pem

Then restart Chrome and run:  python serve.py --https

To undo it later:  certutil -delstore "ROOT" rubaya.com
"""

import datetime
import ipaddress
import os
import sys

try:
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
except ImportError:
    print("This needs the cryptography package. Install it with:")
    print("    pip install cryptography")
    sys.exit(1)

import socket

SITE = "rubaya.com"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "certs")


def lan_ip():
    """Best-guess LAN address, without actually sending any traffic."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()


def main():
    os.makedirs(OUT, exist_ok=True)

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, SITE),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "CFML local development"),
    ])
    now = datetime.datetime.now(datetime.timezone.utc)

    san = [
        x509.DNSName(SITE),
        x509.DNSName(f"www.{SITE}"),
        x509.DNSName("localhost"),
        x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
    ]

    # Extra IPs: auto-detected LAN address, plus any passed on the command
    # line, e.g.  python make_cert.py 192.168.0.111
    extra_ips = {ip for ip in [lan_ip(), *sys.argv[1:]] if ip}
    for ip in sorted(extra_ips):
        try:
            san.append(x509.IPAddress(ipaddress.IPv4Address(ip)))
        except ValueError:
            print(f"Skipping '{ip}': not a valid IPv4 address.")

    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=730))
        .add_extension(x509.SubjectAlternativeName(san), critical=False)
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )

    with open(os.path.join(OUT, "key.pem"), "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ))

    with open(os.path.join(OUT, "cert.pem"), "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    covered = ", ".join([SITE, "127.0.0.1", *sorted(extra_ips)])
    print(f"Wrote certs\\cert.pem and certs\\key.pem, covering: {covered}")
    print()
    print("Trust it once, as Administrator:")
    print('    certutil -addstore -f "ROOT" certs\\cert.pem')
    print()
    print("Then start the site with:  python serve.py --https")


if __name__ == "__main__":
    main()
