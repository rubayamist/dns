r"""
serve.py — serve this folder on port 80, reachable at all of:

    http://127.0.0.1
    http://192.168.0.111        (or whatever this machine's LAN address is)
    http://rubaya.com           (needs the hosts file entry, see README.md)

The server listens on every network interface at once, so all three work
without changing anything — the address is just how you choose to reach it.

Run:  python serve.py            serves port 80 (needs administrator)
      python serve.py 8080       a different port, if 80 is taken
      python serve.py --https    HTTPS on 443, needs certs (see make_cert.py)

About the camera and "secure origins": browsers only hand a page the camera on
an address they consider secure. http://127.0.0.1 and http://localhost are
always treated as secure, no matter what. http://rubaya.com and
http://192.168.0.111 are NOT, even on your own network, because to the browser
they are just plain-HTTP addresses. So:

    http://127.0.0.1            camera works right away
    http://192.168.0.111        camera blocked, needs a fix below
    http://rubaya.com           camera blocked, needs a fix below

Two fixes, both explained in README.md:
  1. start Chrome once with --unsafely-treat-insecure-origin-as-secure
  2. run make_cert.py and use --https here
"""

import http.server
import socket
import socketserver
import os
import ssl
import sys
import webbrowser

SITE = "rubaya.com"
ROOT = os.path.dirname(os.path.abspath(__file__))
CERT = os.path.join(ROOT, "certs", "cert.pem")
KEY = os.path.join(ROOT, "certs", "key.pem")

args = sys.argv[1:]
USE_HTTPS = "--https" in args
ports = [a for a in args if a.isdigit()]
PORT = int(ports[0]) if ports else (443 if USE_HTTPS else 80)


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".mjs": "text/javascript",
        ".js": "text/javascript",
        ".wasm": "application/wasm",
        ".task": "application/octet-stream",
        ".css": "text/css",
        ".html": "text/html",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def end_headers(self):
        # Always serve the newest file while you are editing.
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, fmt, *args):
        pass  # keep the console quiet


def lan_ip():
    """Best-guess LAN address, without actually sending any traffic."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()


def port_help():
    print(f"Port {PORT} is already in use or not allowed.")
    print("On Windows port 80 is usually taken by IIS, by the World Wide Web")
    print("Publishing Service, or by another program using http.sys.")
    print()
    print("Free it from an Administrator Command Prompt:")
    print("    net stop http")
    print("    net stop w3svc")
    print()
    print("Or see what holds it:")
    print("    netstat -ano | findstr :80")
    print()
    print("Or just use another port:")
    print("    python serve.py 8080          then open http://127.0.0.1:8080")


def main():
    if USE_HTTPS and not (os.path.exists(CERT) and os.path.exists(KEY)):
        print("No certificate found in certs\\. Run:  python make_cert.py")
        return 1

    socketserver.TCPServer.allow_reuse_address = True
    try:
        # 0.0.0.0 so every address that reaches this machine — 127.0.0.1, the
        # LAN IP, and rubaya.com from the hosts file — lands on the same
        # server.
        server = socketserver.TCPServer(("0.0.0.0", PORT), Handler)
    except PermissionError:
        print(f"Windows refused port {PORT}. Run this Command Prompt as")
        print("Administrator, or use a high port:  python serve.py 8080")
        return 1
    except OSError:
        port_help()
        return 1

    scheme = "https" if USE_HTTPS else "http"
    if USE_HTTPS:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(CERT, KEY)
        server.socket = context.wrap_socket(server.socket, server_side=True)

    suffix = "" if PORT in (80, 443) else f":{PORT}"
    addresses = ["127.0.0.1", SITE]
    ip = lan_ip()
    if ip:
        addresses.insert(1, ip)

    print(f"CFML is running on port {PORT}. Open any of:\n")
    for addr in addresses:
        secure = addr == "127.0.0.1" or USE_HTTPS
        mark = "camera works" if secure else "camera needs a fix below"
        print(f"    {scheme}://{addr}{suffix}   ({mark})")

    if not USE_HTTPS:
        print()
        print(f"{SITE} and the LAN address are not secure origins over plain HTTP,")
        print("so the camera will likely be blocked there. 127.0.0.1 is exempt and")
        print("just works. To fix the other two, close Chrome and start it once")
        print("with all the addresses you use, comma-separated, one line:")
        origins = ",".join(f'{scheme}://{a}{suffix}' for a in addresses if a != "127.0.0.1")
        print(f'    chrome.exe --unsafely-treat-insecure-origin-as-secure="{origins}"'
              r' --user-data-dir="%TEMP%\cfml-profile"')
        print("Or run:  python make_cert.py   and then:  python serve.py --https")

    print()
    print("From another machine on the network, use the LAN address above (never")
    print("127.0.0.1), and if this is the first time, allow it through the")
    print("firewall from an Administrator Command Prompt:")
    print(f'    netsh advfirewall firewall add rule name="CFML" dir=in action=allow protocol=TCP localport={PORT}')

    print()
    print("Press Ctrl+C to stop.")
    webbrowser.open(f"{scheme}://127.0.0.1{suffix}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
