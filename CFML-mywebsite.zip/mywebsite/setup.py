"""
setup.py — fetch the machine learning model and the MediaPipe runtime into
this folder, so CFML runs with no internet connection afterwards.

Run once:   python setup.py

Downloads (about 12 MB in total):
  models/hand_landmarker.task        the trained hand landmark model
  vendor/vision_bundle.mjs           MediaPipe Tasks Vision, JavaScript side
  vendor/wasm/*                      its WebAssembly runtime

The model is Google's MediaPipe HandLandmarker, trained on roughly 30K real
hand photographs plus a set of rendered synthetic hands. It is published under
the Apache 2.0 licence. Nothing here needs to be trained on your machine.
"""

import os
import sys
import urllib.request

CDN = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14"
MODEL = (
    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
    "hand_landmarker/float16/1/hand_landmarker.task"
)

HERE = os.path.dirname(os.path.abspath(__file__))

FILES = [
    (MODEL, "models/hand_landmarker.task"),
    (f"{CDN}/vision_bundle.mjs", "vendor/vision_bundle.mjs"),
    (f"{CDN}/wasm/vision_wasm_internal.js", "vendor/wasm/vision_wasm_internal.js"),
    (f"{CDN}/wasm/vision_wasm_internal.wasm", "vendor/wasm/vision_wasm_internal.wasm"),
    (f"{CDN}/wasm/vision_wasm_nosimd_internal.js", "vendor/wasm/vision_wasm_nosimd_internal.js"),
    (f"{CDN}/wasm/vision_wasm_nosimd_internal.wasm", "vendor/wasm/vision_wasm_nosimd_internal.wasm"),
]


def fetch(url, rel):
    dest = os.path.join(HERE, rel.replace("/", os.sep))
    os.makedirs(os.path.dirname(dest), exist_ok=True)

    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        print(f"  have    {rel}")
        return True

    print(f"  getting {rel} ...", end=" ", flush=True)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "CFML-setup"})
        with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
            f.write(r.read())
    except Exception as err:
        print("failed")
        print(f"          {err}")
        if os.path.exists(dest):
            os.remove(dest)
        return False

    print(f"{os.path.getsize(dest) // 1024} KB")
    return True


def main():
    print("CFML setup — downloading the model and runtime\n")
    results = [fetch(url, rel) for url, rel in FILES]

    print()
    if all(results):
        print("Done. Everything is in this folder and works offline.")
        print("Next: run  python serve.py  (or double-click run.bat)")
        return 0

    print("Some files are missing.")
    print("Check your connection and run this again. The page still works")
    print("online without them, by loading the model from the internet.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
