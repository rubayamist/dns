/*
 * app.js — camera, model loading and the render loop.
 *
 * The hand landmark model is MediaPipe HandLandmarker. The app prefers the
 * copies inside this folder (vendor/ and models/) so it keeps working with no
 * internet connection; if they are missing it falls back to a public CDN.
 */

import { readHand, Smoother, FINGER_NAMES, CONNECTIONS } from "./fingers.js";

const CDN = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
const MODEL_CDN =
  "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";

const video = document.getElementById("video");
const canvas = document.getElementById("overlay");
const ctx = canvas.getContext("2d");

const el = {
  status: document.getElementById("status"),
  count: document.getElementById("count"),
  hands: document.getElementById("handCount"),
  fps: document.getElementById("fps"),
  modelSrc: document.getElementById("modelSrc"),
  curtain: document.getElementById("curtain"),
  curtainText: document.getElementById("curtainText"),
  start: document.getElementById("startBtn"),
  stop: document.getElementById("stopBtn"),
  mirror: document.getElementById("mirrorChk"),
  skeleton: document.getElementById("skeletonChk"),
  twoHands: document.getElementById("twoHandsChk"),
  list: document.getElementById("fingerList"),
};

const rows = {};
for (const li of el.list.querySelectorAll("li")) rows[li.dataset.name] = li;

let landmarker = null;
let stream = null;
let running = false;
let lastVideoTime = -1;
const smoother = new Smoother();
let frames = 0, fpsClock = performance.now();

function setStatus(text, state = "idle") {
  el.status.textContent = text;
  el.status.dataset.state = state;
}

async function fileExists(url) {
  try {
    const r = await fetch(url, { method: "HEAD" });
    return r.ok;
  } catch {
    return false;
  }
}

async function loadModel() {
  setStatus("Loading the model");

  let vision;
  let libLocal = true;
  try {
    vision = await import("../vendor/vision_bundle.mjs");
  } catch {
    libLocal = false;
    vision = await import(/* @vite-ignore */ `${CDN}/vision_bundle.mjs`);
  }
  const { FilesetResolver, HandLandmarker } = vision;

  const wasmLocal = libLocal && (await fileExists("vendor/wasm/vision_wasm_internal.js"));
  const fileset = await FilesetResolver.forVisionTasks(
    wasmLocal ? "vendor/wasm" : `${CDN}/wasm`
  );

  const modelLocal = await fileExists("models/hand_landmarker.task");
  landmarker = await HandLandmarker.createFromOptions(fileset, {
    baseOptions: {
      modelAssetPath: modelLocal ? "models/hand_landmarker.task" : MODEL_CDN,
      delegate: "GPU",
    },
    runningMode: "VIDEO",
    numHands: 2,
    minHandDetectionConfidence: 0.5,
    minHandPresenceConfidence: 0.5,
    minTrackingConfidence: 0.5,
  });

  el.modelSrc.textContent = modelLocal ? "local folder" : "downloaded";
  setStatus("Model ready");
}

async function startCamera() {
  el.start.disabled = true;
  try {
    if (!landmarker) await loadModel();
  } catch (err) {
    console.error(err);
    setStatus("Model failed to load", "error");
    el.curtainText.innerHTML =
      "The model could not be loaded. Run <strong>python setup.py</strong> once to place it in this folder, or connect to the internet and reload.";
    el.start.disabled = false;
    return;
  }

  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" },
      audio: false,
    });
  } catch (err) {
    console.error(err);
    setStatus("Camera blocked", "error");
    el.curtainText.innerHTML =
      "The browser would not hand over the camera. Check the camera permission for this page, close any other app using the camera, and try again.";
    el.start.disabled = false;
    return;
  }

  video.srcObject = stream;
  await video.play();
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;

  el.curtain.classList.add("hidden");
  el.stop.disabled = false;
  running = true;
  setStatus("Reading your hand", "live");
  requestAnimationFrame(loop);
}

function stopCamera() {
  running = false;
  if (stream) stream.getTracks().forEach((t) => t.stop());
  stream = null;
  video.srcObject = null;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  smoother.reset();
  el.curtain.classList.remove("hidden");
  el.curtainText.innerHTML = "The camera is off. Press <strong>Start camera</strong> to begin again.";
  el.start.disabled = false;
  el.stop.disabled = true;
  el.count.textContent = "—";
  el.hands.textContent = "0";
  for (const name of FINGER_NAMES) rows[name].classList.remove("up");
  setStatus("Camera off");
}

function loop() {
  if (!running) return;

  if (video.currentTime !== lastVideoTime && video.readyState >= 2) {
    lastVideoTime = video.currentTime;
    const result = landmarker.detectForVideo(video, performance.now());
    render(result);
  }

  frames++;
  const now = performance.now();
  if (now - fpsClock > 500) {
    el.fps.textContent = Math.round((frames * 1000) / (now - fpsClock));
    frames = 0;
    fpsClock = now;
  }

  requestAnimationFrame(loop);
}

function render(result) {
  const hands = result.landmarks || [];
  const limit = el.twoHands.checked ? hands.length : Math.min(1, hands.length);

  ctx.save();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (el.mirror.checked) {
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
  }

  let total = 0;
  let firstStates = null;

  for (let h = 0; h < limit; h++) {
    const lm = hands[h];
    const { states, count } = readHand(lm);
    total += count;
    if (h === 0) firstStates = states;
    if (el.skeleton.checked) drawHand(lm, states);
  }

  ctx.restore();

  el.hands.textContent = String(limit);

  if (limit === 0) {
    smoother.reset();
    el.count.textContent = "—";
    for (const name of FINGER_NAMES) rows[name].classList.remove("up");
    return;
  }

  el.count.textContent = String(smoother.push(total));
  for (const name of FINGER_NAMES) {
    rows[name].classList.toggle("up", Boolean(firstStates && firstStates[name]));
  }
}

function drawHand(lm, states) {
  const W = canvas.width, H = canvas.height;
  const up = "#f2b544", down = "#e07a5f";

  ctx.lineWidth = Math.max(2, W / 400);
  ctx.strokeStyle = "rgba(237,242,240,.75)";
  for (const [a, b] of CONNECTIONS) {
    ctx.beginPath();
    ctx.moveTo(lm[a].x * W, lm[a].y * H);
    ctx.lineTo(lm[b].x * W, lm[b].y * H);
    ctx.stroke();
  }

  const tips = { thumb: 4, index: 8, middle: 12, ring: 16, pinky: 20 };
  const r = Math.max(3, W / 220);
  for (let i = 0; i < lm.length; i++) {
    ctx.beginPath();
    ctx.arc(lm[i].x * W, lm[i].y * H, r, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(237,242,240,.9)";
    ctx.fill();
  }
  for (const [name, i] of Object.entries(tips)) {
    ctx.beginPath();
    ctx.arc(lm[i].x * W, lm[i].y * H, r * 2, 0, Math.PI * 2);
    ctx.fillStyle = states[name] ? up : down;
    ctx.fill();
  }
}

// Mirroring the video is a CSS-level flip; the canvas handles its own flip above.
function applyMirror() {
  video.style.transform = el.mirror.checked ? "scaleX(-1)" : "none";
}

el.start.addEventListener("click", startCamera);
el.stop.addEventListener("click", stopCamera);
el.mirror.addEventListener("change", applyMirror);
applyMirror();

window.addEventListener("beforeunload", () => {
  if (stream) stream.getTracks().forEach((t) => t.stop());
});

if (location.protocol === "file:") {
  setStatus("Open through the local server", "error");
  el.curtainText.innerHTML =
    "This page is open as a file. Browsers block cameras and modules on <code>file://</code>. Double-click <strong>run.bat</strong> and open <strong>http://rubaya.com</strong>.";
  el.start.disabled = true;
} else if (!window.isSecureContext) {
  // http://rubaya.com is not a secure origin, so the browser may refuse the
  // camera even though the page itself loads fine.
  setStatus("Origin is not secure", "error");
  el.curtainText.innerHTML =
    "This address is plain HTTP, so the browser may refuse the camera. Press <strong>Start camera</strong> to try anyway. If it is blocked, see the two fixes in <strong>README.md</strong>: the Chrome flag, or <strong>python make_cert.py</strong> then <strong>python serve.py --https</strong>.";
}
