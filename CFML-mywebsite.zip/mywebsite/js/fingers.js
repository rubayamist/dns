/*
 * fingers.js — turn 21 hand landmarks into a finger count.
 *
 * Landmark numbering used by MediaPipe HandLandmarker:
 *
 *        8   12  16  20      <- finger tips
 *        7   11  15  19
 *        6   10  14  18      <- PIP joints
 *        5    9  13  17      <- MCP knuckles
 *   4                        <- thumb tip
 *    3
 *     2
 *      1
 *        0                   <- wrist
 *
 * Everything below is measured with angles and ratios rather than raw
 * screen positions, so the result holds up when the hand is rotated or
 * when it moves closer to or further from the lens.
 */

export const FINGER_NAMES = ["thumb", "index", "middle", "ring", "pinky"];

// Tunable. Raise a threshold to make that finger harder to register as up.
export const TUNING = {
  fingerAngle: 150,   // degrees at the PIP joint before a finger counts as straight
  thumbAngle: 145,    // degrees at the thumb IP joint
  thumbSpread: 1.0,   // thumb tip must be this much further from the palm than its own knuckle
  voteFrames: 6,      // how many recent frames feed the rolling vote
};

const CHAINS = {
  index:  [5, 6, 8],
  middle: [9, 10, 12],
  ring:   [13, 14, 16],
  pinky:  [17, 18, 20],
};

function dist(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y, dz = (a.z || 0) - (b.z || 0);
  return Math.hypot(dx, dy, dz);
}

// Interior angle at point b, in degrees.
function angle(a, b, c) {
  const v1 = { x: a.x - b.x, y: a.y - b.y, z: (a.z || 0) - (b.z || 0) };
  const v2 = { x: c.x - b.x, y: c.y - b.y, z: (c.z || 0) - (b.z || 0) };
  const dot = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
  const mag = Math.hypot(v1.x, v1.y, v1.z) * Math.hypot(v2.x, v2.y, v2.z);
  if (mag === 0) return 180;
  return (Math.acos(Math.max(-1, Math.min(1, dot / mag))) * 180) / Math.PI;
}

/**
 * Decide which fingers are extended on one hand.
 * @param {Array<{x:number,y:number,z:number}>} lm 21 landmarks
 * @returns {{states:Object, count:number}}
 */
export function readHand(lm) {
  const states = {};

  for (const name of ["index", "middle", "ring", "pinky"]) {
    const [mcp, pip, tip] = CHAINS[name];
    states[name] = angle(lm[mcp], lm[pip], lm[tip]) > TUNING.fingerAngle;
  }

  // The thumb bends sideways rather than curling, so it needs its own test:
  // the knuckle must be reasonably straight AND the tip must sit further from
  // the far side of the palm than the thumb's own base does.
  const straight = angle(lm[2], lm[3], lm[4]) > TUNING.thumbAngle;
  const away = dist(lm[4], lm[17]) > dist(lm[2], lm[17]) * TUNING.thumbSpread;
  states.thumb = straight && away;

  const count = FINGER_NAMES.reduce((n, f) => n + (states[f] ? 1 : 0), 0);
  return { states, count };
}

/**
 * Rolling vote. Raw per-frame readings jitter by a finger or two, especially
 * at the moment a finger starts to move; reporting the most common value from
 * the last few frames gives a number a person can actually read.
 */
export class Smoother {
  constructor(size = TUNING.voteFrames) {
    this.size = size;
    this.buf = [];
  }
  push(value) {
    this.buf.push(value);
    if (this.buf.length > this.size) this.buf.shift();
    const tally = new Map();
    for (const v of this.buf) tally.set(v, (tally.get(v) || 0) + 1);
    let best = value, bestN = -1;
    for (const [v, n] of tally) if (n > bestN) { best = v; bestN = n; }
    return best;
  }
  reset() {
    this.buf.length = 0;
  }
}

// Pairs of landmark indices, used only for drawing the skeleton.
export const CONNECTIONS = [
  [0,1],[1,2],[2,3],[3,4],
  [0,5],[5,6],[6,7],[7,8],
  [5,9],[9,10],[10,11],[11,12],
  [9,13],[13,14],[14,15],[15,16],
  [13,17],[17,18],[18,19],[19,20],
  [0,17],
];
