@echo off
title CFML - rubaya.com
cd /d "%~dp0"

if not exist "models\hand_landmarker.task" (
  echo First run: downloading the model...
  python setup.py
)

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Port 80 usually needs an Administrator Command Prompt.
  echo If the server refuses to start, close this window, right-click
  echo run.bat and choose Run as administrator.
  echo.
)

if exist "certs\cert.pem" (
  python serve.py --https
) else (
  python serve.py
)
pause
